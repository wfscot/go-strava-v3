# TimedZoneRange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Min** | **int32** | The minimum value in the range. | [optional] [default to null]
**Max** | **int32** | The maximum value in the range. | [optional] [default to null]
**Time** | **int32** | The number of seconds spent in this zone | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


