# HeartRateZoneRanges

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CustomZones** | **bool** | Whether the athlete has set their own custom heart rate zones | [optional] [default to null]
**Zones** | [***ZoneRanges**](ZoneRanges.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


