# ActivityZone

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Score** | **int32** |  | [optional] [default to null]
**DistributionBuckets** | [***TimedZoneDistribution**](TimedZoneDistribution.md) |  | [optional] [default to null]
**Type_** | **string** |  | [optional] [default to null]
**SensorBased** | **bool** |  | [optional] [default to null]
**Points** | **int32** |  | [optional] [default to null]
**CustomZones** | **bool** |  | [optional] [default to null]
**Max** | **int32** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


