# PhotosSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Count** | **int32** | The number of photos | [optional] [default to null]
**Primary** | [***PhotosSummaryPrimary**](PhotosSummary_primary.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


