# PolylineMap

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | The identifier of the map | [optional] [default to null]
**Polyline** | **string** | The polyline of the map, only returned on detailed representation of an object | [optional] [default to null]
**SummaryPolyline** | **string** | The summary polyline of the map | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


